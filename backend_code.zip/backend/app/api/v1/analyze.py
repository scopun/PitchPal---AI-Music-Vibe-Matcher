import os
import shutil
import tempfile
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from typing import Optional
from app.services.audio_engine import analyze_demo_track
from app.services.matcher import find_best_match

router = APIRouter()

@router.post("/match")
async def match_artist(
    lyrics: str = Form(...),
    audio_file: Optional[UploadFile] = File(None),
    debug: bool = Form(False)
):
    temp_file_path = ""

    try:
        audio_features = {}

        # Audio is optional — only process if provided
        if audio_file and audio_file.filename:
            filename = audio_file.filename.lower()

            if not filename.endswith((".mp3", ".wav", ".m4a")):
                raise HTTPException(status_code=400, detail="Invalid file format. Use MP3, WAV or M4A.")

            suffix = os.path.splitext(filename)[1] if "." in filename else ".mp3"
            fd, temp_file_path = tempfile.mkstemp(suffix=suffix)
            os.close(fd)

            with open(temp_file_path, "wb") as buffer:
                shutil.copyfileobj(audio_file.file, buffer)

            audio_features = analyze_demo_track(temp_file_path) or {}

        # Run AI matching (works with or without audio features)
        results = await find_best_match(audio_features, lyrics)

        if isinstance(results, dict):
            results["success"] = True
            if debug and audio_features:
                results["extracted_features"] = audio_features
            return results
        else:
            return {
                "success": True,
                "matches": results,
            }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if temp_file_path and os.path.exists(temp_file_path):
            try:
                os.remove(temp_file_path)
            except Exception:
                pass